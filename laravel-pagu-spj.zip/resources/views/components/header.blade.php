<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <form class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li><a href="#"
                    data-toggle="sidebar"
                    class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
            <li><a href="#"
                    data-toggle="search"
                    class="nav-link nav-link-lg d-sm-none"><i class="fas fa-search"></i></a></li>
        </ul>
    </form>

    <ul class="navbar-nav navbar-right">
        <li class="dropdown">
            <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user d-flex align-items-center">
                {{-- Tahun di kiri logo --}}
                <div class="tahun-info mr-3 bg-white text-dark border px-2 py-1 rounded">
                    Tahun Anggaran: {{ session('tahun') }}
                </div>

                {{-- Logo dan info user --}}
                <img alt="image" src="{{ asset('img/logo_pemda.png') }}" class="mr-2 logo-pemda">
                <div class="user-info">
                    <div class="kab-info">Selamat Datang</div>
                    <div class="user-name">{{ auth()->user()->name }}</div>
                </div>
            </a>

            <div class="dropdown-menu dropdown-menu-right">
                <a href="#" class="dropdown-item has-icon text-danger" onclick="event.preventDefault(); document.getElementById('logout-form').submit()">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </div>
        </li>
    </ul>
</nav>


